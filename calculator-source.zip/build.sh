#!/usr/bin/env bash
# Builds two WAR files:
#   dist/calculator.war          -> for Tomcat 10.1 / 11  (jakarta.servlet)
#   dist/calculator-tomcat9.war  -> for Tomcat 9 or 8.5   (javax.servlet)
set -euo pipefail
cd "$(dirname "$0")"

mvn -q -B clean package
mkdir -p dist
cp target/calculator.war dist/calculator.war

# Tomcat 9 variant: same source, but the package name is javax.servlet
rm -rf build-tomcat9
mkdir build-tomcat9
cp -r pom.xml src build-tomcat9/
find build-tomcat9/src -name '*.java' -exec sed -i 's/jakarta\.servlet/javax.servlet/g' {} +
sed -i \
  -e 's#https://jakarta.ee/xml/ns/jakartaee/web-app_6_0.xsd#http://xmlns.jcp.org/xml/ns/javaee/web-app_4_0.xsd#' \
  -e 's#https://jakarta.ee/xml/ns/jakartaee#http://xmlns.jcp.org/xml/ns/javaee#g' \
  -e 's#version="6.0"#version="4.0"#' \
  build-tomcat9/src/main/webapp/WEB-INF/web.xml
( cd build-tomcat9 && mvn -q -B -Ptomcat9 clean package )
cp build-tomcat9/target/calculator.war dist/calculator-tomcat9.war
rm -rf build-tomcat9

echo "Done:"
ls -l dist/*.war
