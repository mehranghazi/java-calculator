package com.example.calc;

import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

/** Tiny JSON helpers so the app needs no extra libraries. */
final class Json {

    private Json() {}

    static String esc(String s) {
        StringBuilder sb = new StringBuilder(s.length() + 8);
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            switch (c) {
                case '"':  sb.append("\\\""); break;
                case '\\': sb.append("\\\\"); break;
                case '\n': sb.append("\\n");  break;
                case '\r': sb.append("\\r");  break;
                case '\t': sb.append("\\t");  break;
                default:
                    if (c < 0x20) {
                        sb.append(String.format("\\u%04x", (int) c));
                    } else {
                        sb.append(c);
                    }
            }
        }
        return sb.toString();
    }

    /** JSON string literal, or null. */
    static String str(String s) {
        return s == null ? "null" : "\"" + esc(s) + "\"";
    }

    static void write(HttpServletResponse resp, int status, String json) throws IOException {
        resp.setStatus(status);
        resp.setContentType("application/json");
        resp.setCharacterEncoding("UTF-8");
        resp.setHeader("Cache-Control", "no-store");
        resp.getWriter().write(json);
    }

    static void error(HttpServletResponse resp, int status, String message) throws IOException {
        write(resp, status, "{\"error\":" + str(message) + "}");
    }
}
