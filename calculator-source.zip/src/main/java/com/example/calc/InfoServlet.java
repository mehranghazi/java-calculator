package com.example.calc;

import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.lang.management.ManagementFactory;
import java.lang.management.RuntimeMXBean;
import java.util.List;

/**
 * GET api/info -> what the JVM looks like right now.
 * This is how you can SEE that CATALINA_OPTS reached the application:
 * heap size (-Xmx), -D settings and the raw CATALINA_OPTS variable are all reported.
 */
public class InfoServlet extends HttpServlet {

    private static final long MB = 1024L * 1024L;

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        Runtime rt = Runtime.getRuntime();
        RuntimeMXBean rb = ManagementFactory.getRuntimeMXBean();

        StringBuilder args = new StringBuilder("[");
        List<String> jvmArgs = rb.getInputArguments();
        for (int i = 0; i < jvmArgs.size(); i++) {
            if (i > 0) {
                args.append(',');
            }
            args.append(Json.str(jvmArgs.get(i)));
        }
        args.append(']');

        long total = rt.totalMemory();
        long used = total - rt.freeMemory();

        String json = "{"
                + "\"appName\":" + Json.str(Config.APP_NAME)
                + ",\"server\":" + Json.str(getServletContext().getServerInfo())
                + ",\"java\":" + Json.str(System.getProperty("java.version"))
                + ",\"os\":" + Json.str(System.getProperty("os.name"))
                + ",\"cpus\":" + rt.availableProcessors()
                + ",\"heapMaxMb\":" + (rt.maxMemory() / MB)
                + ",\"heapCommittedMb\":" + (total / MB)
                + ",\"heapUsedMb\":" + (used / MB)
                + ",\"threads\":" + ManagementFactory.getThreadMXBean().getThreadCount()
                + ",\"uptimeSec\":" + (rb.getUptime() / 1000L)
                + ",\"catalinaOptsEnv\":" + Json.str(System.getenv("CATALINA_OPTS"))
                + ",\"jvmArgs\":" + args
                + ",\"config\":{"
                +     "\"app.name\":" + Json.str(Config.APP_NAME)
                +     ",\"app.stress.enabled\":" + Config.STRESS_ENABLED
                +     ",\"app.stress.maxCpuMs\":" + Config.MAX_CPU_MS
                +     ",\"app.stress.maxAllocMb\":" + Config.MAX_ALLOC_MB
                +     ",\"app.stress.maxThreads\":" + Config.MAX_THREADS
                + "}"
                + ",\"stress\":{"
                +     "\"inFlight\":" + StressServlet.IN_FLIGHT.get()
                +     ",\"completed\":" + StressServlet.COMPLETED.get()
                +     ",\"failed\":" + StressServlet.FAILED.get()
                + "}"
                + "}";
        Json.write(resp, 200, json);
    }
}
