package com.example.calc;

import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Load / stress endpoint.
 *
 * GET api/stress?cpuMs=200&threads=1&allocMb=0
 *   cpuMs    - how long to keep the CPU busy (per thread)
 *   threads  - how many busy threads this single request starts
 *   allocMb  - how much heap memory to hold while the request runs
 *
 * All values are capped by the limits in Config (set through CATALINA_OPTS).
 * If the JVM heap (-Xmx in CATALINA_OPTS) is too small the request answers 500
 * with "OutOfMemoryError" instead of crashing Tomcat.
 */
public class StressServlet extends HttpServlet {

    static final AtomicInteger IN_FLIGHT = new AtomicInteger();
    static final AtomicInteger COMPLETED = new AtomicInteger();
    static final AtomicInteger FAILED = new AtomicInteger();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        if (!Config.STRESS_ENABLED) {
            Json.error(resp, 403, "Stress endpoint is disabled (-Dapp.stress.enabled=false)");
            return;
        }

        int cpuMs = clamp(intParam(req, "cpuMs", 200), 0, Config.MAX_CPU_MS);
        int allocMb = clamp(intParam(req, "allocMb", 0), 0, Config.MAX_ALLOC_MB);
        int threads = clamp(intParam(req, "threads", 1), 1, Config.MAX_THREADS);

        long start = System.nanoTime();
        IN_FLIGHT.incrementAndGet();
        try {
            // 1) hold some memory (touch every page so it is really used)
            List<byte[]> held = new ArrayList<>();
            for (int i = 0; i < allocMb; i++) {
                byte[] chunk = new byte[1024 * 1024];
                for (int j = 0; j < chunk.length; j += 4096) {
                    chunk[j] = 1;
                }
                held.add(chunk);
            }

            // 2) burn CPU
            long checksum = burn(cpuMs, threads);

            COMPLETED.incrementAndGet();
            long tookMs = (System.nanoTime() - start) / 1_000_000L;
            Json.write(resp, 200, "{\"ok\":true,\"tookMs\":" + tookMs
                    + ",\"cpuMs\":" + cpuMs + ",\"threads\":" + threads
                    + ",\"heldMb\":" + held.size()
                    + ",\"worker\":" + Json.str(Thread.currentThread().getName())
                    + ",\"checksum\":" + checksum + "}");
        } catch (OutOfMemoryError oom) {
            FAILED.incrementAndGet();
            Json.write(resp, 500, "{\"ok\":false,\"error\":\"OutOfMemoryError\","
                    + "\"hint\":\"Increase -Xmx in CATALINA_OPTS or lower allocMb / concurrency\"}");
        } catch (InterruptedException ie) {
            Thread.currentThread().interrupt();
            FAILED.incrementAndGet();
            Json.error(resp, 500, "Interrupted");
        } finally {
            IN_FLIGHT.decrementAndGet();
        }
    }

    private static long burn(int ms, int threads) throws InterruptedException {
        if (ms <= 0) {
            return 0;
        }
        final long deadline = System.nanoTime() + ms * 1_000_000L;
        final long[] out = new long[threads];
        Thread[] workers = new Thread[threads];
        for (int t = 0; t < threads; t++) {
            final int idx = t;
            workers[t] = new Thread(() -> {
                long acc = idx;
                while (System.nanoTime() < deadline) {
                    for (int i = 1; i < 20000; i++) {
                        acc += (long) Math.sqrt(i * 31L + (acc & 1023)) + (acc >>> 3);
                    }
                }
                out[idx] = acc;
            }, "stress-burn-" + t);
            workers[t].setDaemon(true);
            workers[t].start();
        }
        long sum = 0;
        for (int t = 0; t < threads; t++) {
            workers[t].join();
            sum ^= out[t];
        }
        return sum;
    }

    private static int intParam(HttpServletRequest req, String name, int def) {
        String v = req.getParameter(name);
        if (v == null) {
            return def;
        }
        try {
            return Integer.parseInt(v.trim());
        } catch (NumberFormatException e) {
            return def;
        }
    }

    private static int clamp(int v, int lo, int hi) {
        return Math.max(lo, Math.min(hi, v));
    }
}
