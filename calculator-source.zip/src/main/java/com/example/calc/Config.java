package com.example.calc;

/**
 * Settings read from JVM system properties (-Dname=value).
 *
 * You set these through CATALINA_OPTS, e.g.
 *   CATALINA_OPTS="-Xmx512m -Dapp.name=MyCalc -Dapp.stress.maxCpuMs=5000"
 * Tomcat's startup script (catalina.sh) adds CATALINA_OPTS to the java command line,
 * so every -D option there becomes a System property that this class can read.
 */
public final class Config {

    private Config() {}

    /** Title shown in the web page. */
    public static final String APP_NAME =
            System.getProperty("app.name", "Tomcat Calculator");

    /** Master switch for the stress endpoint. */
    public static final boolean STRESS_ENABLED =
            Boolean.parseBoolean(System.getProperty("app.stress.enabled", "true"));

    /** Safety cap: max CPU burn time per request (milliseconds). */
    public static final int MAX_CPU_MS =
            Integer.getInteger("app.stress.maxCpuMs", 3000);

    /** Safety cap: max memory held by one request (megabytes). */
    public static final int MAX_ALLOC_MB =
            Integer.getInteger("app.stress.maxAllocMb", 128);

    /** Safety cap: max burner threads inside one request. */
    public static final int MAX_THREADS =
            Integer.getInteger("app.stress.maxThreads",
                    Math.max(1, Runtime.getRuntime().availableProcessors()));
}
