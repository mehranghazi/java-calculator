package com.example.calc;

import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * GET api/calc?op=add&a=2&b=3   ->  {"a":2.0,"b":3.0,"op":"add","result":5.0}
 * ops: add, sub, mul, div, mod, pow
 */
public class CalcServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        String op = req.getParameter("op");
        if (op == null) {
            Json.error(resp, 400, "Missing parameter: op (add, sub, mul, div, mod, pow)");
            return;
        }

        double a;
        double b;
        try {
            a = Double.parseDouble(req.getParameter("a"));
            b = Double.parseDouble(req.getParameter("b"));
        } catch (NullPointerException | NumberFormatException e) {
            Json.error(resp, 400, "Parameters a and b must be numbers");
            return;
        }

        double result;
        switch (op) {
            case "add": result = a + b; break;
            case "sub": result = a - b; break;
            case "mul": result = a * b; break;
            case "div":
                if (b == 0) {
                    Json.error(resp, 400, "Division by zero");
                    return;
                }
                result = a / b;
                break;
            case "mod":
                if (b == 0) {
                    Json.error(resp, 400, "Modulo by zero");
                    return;
                }
                result = a % b;
                break;
            case "pow": result = Math.pow(a, b); break;
            default:
                Json.error(resp, 400, "Unknown op: " + op);
                return;
        }

        if (Double.isNaN(result) || Double.isInfinite(result)) {
            Json.error(resp, 400, "Result is not a finite number");
            return;
        }

        Json.write(resp, 200, "{\"a\":" + a + ",\"b\":" + b
                + ",\"op\":" + Json.str(op) + ",\"result\":" + result + "}");
    }
}
